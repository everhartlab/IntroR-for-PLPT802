# An installation file for binder
install.packages("tidyverse")
install.packages("agricolae")

